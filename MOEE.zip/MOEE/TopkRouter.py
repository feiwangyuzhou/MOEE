import torch
import torch.nn as nn
import torch.nn.functional as F
import pdb
class TopkRouter(torch.nn.Module):
    def __init__(self, n_embed, num_experts, top_k):
        super(TopkRouter, self).__init__()
        self.top_k = top_k
        self.linear = nn.Linear(n_embed*2, num_experts)

    def forward(self, sub_embed, rel_embed):
        hr_output = torch.cat([sub_embed, rel_embed], dim=1)
        logits = self.linear(hr_output)  # (2,4,32) ---> (2,4,4)
        top_k_logits, indices = logits.topk(self.top_k, dim=-1)
        zeros = torch.full_like(logits, float('-inf'))
        sparse_logits = zeros.scatter(-1, indices, top_k_logits)
        router_output = F.softmax(sparse_logits, dim=-1)
        return router_output, indices


class NoisyTopkRouter(torch.nn.Module):
    def __init__(self, n_embed, num_experts, top_k):
        super(NoisyTopkRouter, self).__init__()
        self.top_k = top_k
        self.topkroute_linear = nn.Linear(n_embed*2, num_experts)
        # add noise
        self.noise_linear = nn.Linear(n_embed*2, num_experts)

    def forward(self, sub_embed, rel_embed):
        # pdb.set_trace()
        # mh_ouput is the output tensor from multihead self attention block
        hr_output = torch.cat([sub_embed, rel_embed], dim=1)
        logits = self.topkroute_linear(hr_output)

        # Noise logits
        noise_logits = self.noise_linear(hr_output)

        # Adding scaled unit gaussian noise to the logits
        noise = torch.randn_like(logits) * F.softplus(noise_logits)
        noisy_logits = logits + noise

        top_k_logits, indices = noisy_logits.topk(self.top_k, dim=-1)
        zeros = torch.full_like(noisy_logits, float('-inf'))
        sparse_logits = zeros.scatter(-1, indices, top_k_logits)
        router_output = F.softmax(sparse_logits, dim=-1)
        return router_output, indices