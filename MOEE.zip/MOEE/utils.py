import numpy as np
import copy
import time

import torch
import torch.nn as nn
from torch.autograd import Variable
import torch.cuda as cuda
import torch.optim as optim
import torch.nn.functional as F

import warnings
warnings.filterwarnings("ignore")
import pdb

from collections import OrderedDict

def top_N(labels,logits,n=1):
	"""
	parameters:
		labels:N
		logits:N * (m+1)
	"""
	scores_dict=OrderedDict()
	for _batch_index,scores in enumerate(logits):
		sample_dict=dict()
		for _index,score in enumerate(scores):
			sample_dict[_index]=score
		sample_dict=sorted(sample_dict.items(),key = lambda x:x[1],reverse = True)
		results=[tuple_item[0] for tuple_item in sample_dict]
		scores_dict[_batch_index] = results
	all_scores = 0
	for _key,_value in scores_dict.items():
		n_value=_value[:n]
		if 0 in n_value:
			all_scores +=1
	acc_n = all_scores *1.0 / len(labels)
	return acc_n


def TopMetrics(top_list,label_list,logits_list):
	eval_metrics=dict()
	for num in top_list:
		key_metrics = "acc_%d"%(num)
		eval_metrics[key_metrics] = top_N(label_list, logits_list, num)
	return eval_metrics






def seq_batch(phrase_id, phrase_all, phrase_len_all, args):
    # pdb.set_trace()
    phrase_batch = phrase_all[phrase_id]
    phrase_len = phrase_len_all[phrase_id]

    # phrase_batch = Variable(phrase_batch)
    # phrase_len = Variable(phrase_len)
    #
    # if args.use_cuda:
    #     phrase_batch = phrase_batch.cuda()
    #     phrase_len = phrase_len.cuda()

    return phrase_batch, phrase_len


def get_neg_samples(pos_samples, unq_ent, unq_rels, args):
    # pdb.set_trace()
    size_of_batch = len(pos_samples)
    num_to_generate = size_of_batch * args.neg_samples
    neg_samples = np.tile(pos_samples, (args.neg_samples, 1))

    values = np.random.choice(unq_ent, size=num_to_generate)
    neg_samples[:, 2] = values

    num_to_generate_rel = size_of_batch * args.rel_neg_samples
    rel_neg_samples = np.tile(pos_samples, (args.rel_neg_samples, 1))

    rel_values = np.random.choice(unq_rels, size=num_to_generate_rel)
    rel_neg_samples[:, 1] = rel_values

    pos_labels = np.ones(len(pos_samples))
    neg_labels = np.zeros(len(neg_samples)+len(rel_neg_samples))

    samples = np.concatenate((pos_samples, neg_samples, rel_neg_samples))
    labels = np.concatenate((pos_labels, neg_labels))
    # pdb.set_trace()
    samples = torch.from_numpy(samples)
    labels = torch.from_numpy(labels).float()

    if args.use_cuda:
        samples = samples.cuda()
        labels = labels.cuda()

    return samples, labels


def get_next_batch(id_list, data, args, train, node_id, rel_id):
    # pdb.set_trace()
    pos_samples = train[id_list]
    tail_ents = set()
    rels = set()

    for i in range(len(id_list)):
        trip = train[id_list[i]]
        pos_ids = data.label_graph[(trip[0],trip[1])]

        tail_ents.update(pos_ids)
        tail_ents.add(trip[0])
        tail_ents.add(trip[2])

        pos_ids_rel = data.label_graph_rel[(trip[0], trip[2])]
        rels.update(pos_ids_rel)
        rels.add(trip[1])

    # pdb.set_trace()
    unq_ents = node_id.difference(tail_ents)
    unq_ents = list(unq_ents)

    unq_rels = rel_id.difference(rels)
    unq_rels = list(unq_rels)
    samples, labels = get_neg_samples(pos_samples, unq_ents, unq_rels, args)

    e_batch, e_len = seq_batch(samples[:, 0], data.ent_phrase_all, data.ent_phrase_len_all, args)
    r_batch, r_len = seq_batch(samples[:, 1], data.rel_phrase_all, data.rel_phrase_len_all, args)

    return samples, labels, e_batch, e_len, r_batch, r_len


def get_next_batch_test(head, rel, tail, args, data, node_id, rel_id):
    pos_samples = []
    tail_ents = set()
    rels = set()
    for i in range(len(head)):
        pos_samples.append([head[i], rel[i], tail[i]])

        if (head[i], rel[i]) in data.label_graph:
            pos_ids = data.label_graph[(head[i], rel[i])]
            tail_ents.update(pos_ids)

        tail_ents.add(head[i])
        tail_ents.add(tail[i])

        if (head[i], tail[i]) in data.label_graph_rel:
            pos_ids_rel = data.label_graph_rel[(head[i], tail[i])]
            rels.update(pos_ids_rel)
        rels.add(rel[i])


    unq_ents = node_id.difference(tail_ents)
    unq_ents = list(unq_ents)

    unq_rels = rel_id.difference(rels)
    unq_rels = list(unq_rels)

    samples, labels = get_neg_samples(pos_samples, unq_ents, unq_rels, args)

    e_batch, e_len = seq_batch(samples[:, 0], data.ent_phrase_all, data.ent_phrase_len_all, args)
    r_batch, r_len = seq_batch(samples[:, 1], data.rel_phrase_all, data.rel_phrase_len_all, args)

    return samples, labels, e_batch, e_len, r_batch, r_len

def get_rank_entity(scores, tail, Hits, entid2clustid, filter_clustID):
    hits = np.ones((len(Hits)))
    scores = np.argsort(scores)
    rank = 1
    for i in range(scores.shape[0]):
        if scores[i] == tail:
            break
        else:
            if entid2clustid[scores[i]] not in filter_clustID:
                rank += 1
    for i,r in enumerate(Hits):
        if rank>r: hits[i]=0
        else: break
    return rank,hits

def get_rank_mention(scores,clust,Hits,entid2clustid,filter_clustID):
    hits = np.ones((len(Hits)))
    # pdb.set_trace()
    scores = np.argsort(scores)
    rank = 1
    high_rank_clust = set()
    # pdb.set_trace()
    for i in range(scores.shape[0]):
        if scores[i] in clust: break
        else:
            if entid2clustid[scores[i]] not in high_rank_clust and entid2clustid[scores[i]] not in filter_clustID:
                rank+=1
                high_rank_clust.add(entid2clustid[scores[i]])
    for i,r in enumerate(Hits):
        if rank>r: hits[i]=0
        else: break
    return rank,hits

def get_rank_cluster(scores, t_clust_id, Hits, entid2clustid, filter_clustID):
    # pdb.set_trace()
    AC_hits = np.ones((len(Hits)))
    DC_hits = np.ones((len(Hits)))

    # Ascending order add -, so Descending order.
    # Return the entityid
    scores = np.argsort(scores)
    # Find all scores of clusters, by averaging all the entity scores in the cluster,
    # Ascending sort them
    clusterScores = {} #store the position of entityid
    for i in range(scores.shape[0]):
        entityid = scores[i]
        clustid = entid2clustid[entityid]
        if clustid not in clusterScores:
            clusterScores[clustid] = []
        if i not in clusterScores[clustid]:
            clusterScores[clustid].append(i)
        # else:
        #     pdb.set_trace()
    # pdb.set_trace()
    clusterScores_true = clusterScores[t_clust_id]

    clusterScores_mean = []
    for clustid_i in range(len(clusterScores)):
        mean_i = np.mean(clusterScores[clustid_i])
        clusterScores_mean.append(mean_i)
    # pdb.set_trace()

    # Return the clusterid
    clusterScores_mean = np.argsort(clusterScores_mean)


    # AC
    AC_rank = 1
    for i in range(clusterScores_mean.shape[0]):
        if clusterScores_mean[i] == t_clust_id:
            # pdb.set_trace()
            break
        else:
            if clusterScores_mean[i] not in filter_clustID:
                AC_rank += 1
    # pdb.set_trace()
    for i, r in enumerate(Hits):
        if AC_rank > r:
            AC_hits[i] = 0
        else:
            break
    # pdb.set_trace()
    # DC
    DC=0
    first0 = clusterScores_true[0]
    for entity_p in clusterScores_true[1:]:
        DC=DC+(entity_p-first0)
    # pdb.set_trace()
    Del = len(clusterScores_true)*(len(clusterScores_true)-1)/2
    DC = DC-Del

    if DC != 0:
        DC = DC / (len(clusterScores_true)-1)

    for i, r in enumerate(Hits):
        if DC + 1 > r:
            DC_hits[i] = 0
        else:
            break

    DC_delete1 = False
    if len(clusterScores_true) == 1:
        DC_delete1 = True

    return AC_rank, AC_hits, DC, DC_hits, DC_delete1


def evaluate_neg(model, entTotal, num_rels, test_trips, args, data):
    ents = torch.arange(0, entTotal, dtype=torch.long)
    head = test_trips[:, 0]
    rel = test_trips[:, 1]
    tail = test_trips[:, 2]
    bs = args.batch_size
    node_id_list = set([m for m in range(args.num_nodes)])
    rel_id_list = set([m for m in range(args.num_rels)])

    if args.use_cuda:
        ents = ents.cuda()

    acc = 0.0
    n_batches = int(test_trips.shape[0]/bs) + 1

    for i in range(n_batches):
        ent_head = head[i * bs:min((i + 1) * bs, test_trips.shape[0])]
        r = rel[i * bs:min((i + 1) * bs, test_trips.shape[0])]
        ent_tail = tail[i * bs:min((i + 1) * bs, test_trips.shape[0])]
        samples, labels, e_batch, e_len, r_batch, r_len = get_next_batch_test(ent_head, r, ent_tail, args, data, node_id_list, rel_id_list)
        # samples = Variable(torch.from_numpy(samples))
        # labels = Variable(torch.from_numpy(labels).float())
        # if args.use_cuda:
        #     samples = samples.cuda()
        #     labels = labels.cuda()

        # if len(samples) != 1408:
        #     pdb.set_trace()
        scores, batch_acc = model(samples, ents, e_batch, e_len, r_batch, r_len, labels)
        acc += batch_acc["acc_1"]

    acc = acc / n_batches
    return acc







def evaluate(model, entTotal, num_rels, test_trips, args, data):
    ents = torch.arange(0, entTotal, dtype=torch.long)
    rel_id = torch.arange(0, num_rels, dtype=torch.long)
    H_Rank = []
    H_inv_Rank = []
    H_Hits = np.zeros((len(args.Hits)))
    T_Rank = []
    T_inv_Rank = []
    T_Hits = np.zeros((len(args.Hits)))
    head = test_trips[:,0]
    rel = test_trips[:,1]
    tail = test_trips[:,2]
    id2ent = data.id2ent
    id2rel = data.id2rel
    true_clusts = data.true_clusts
    entid2clustid = data.entid2clustid
    ent_filter = data.label_filter
    bs = args.batch_size
    
    # edges = torch.tensor(data.edges,dtype=torch.long)
    if args.use_cuda:
        ents = ents.cuda()
    #     # edges = edges.cuda()
    #     rel_id = rel_id.cuda()
    
    # test_scores = np.zeros((test_trips.shape[0],entTotal))
    # n_batches = int(test_trips.shape[0]/bs) + 1

    # for i in range(n_batches):
    #     # print(i)
    #     ent_head = head[i * bs:min((i + 1) * bs, test_trips.shape[0])]
    #     # ent = ent_embed[ent, :]
    #     r = rel[i * bs:min((i + 1) * bs, test_trips.shape[0])]
    #     # r = r_embed[r, :]
    #     ent_tail = tail[i * bs:min((i + 1) * bs, test_trips.shape[0])]
    #     samples = get_next_batch_test(ent_head, r, ent_tail)
    #     samples = Variable(torch.from_numpy(samples))
    #     if args.use_cuda:
    #         samples = samples.cuda()
    #         # edges_ent_batch = edges_ent_batch.cuda()
    #         # edges_rel_batch = edges_rel_batch.cuda()
    #     scores = model.get_embed_my(samples, ents)
    #     test_scores[i * bs:min((i + 1) * bs, test_trips.shape[0]), :] = scores.cpu().data.numpy()


    # for i in range(n_batches):
    #     ent = head[i*bs:min((i+1)*bs,test_trips.shape[0])]
    #     ent = ent_embed[ent,:]
    #     r = r_embed[i*bs:min((i+1)*bs,test_trips.shape[0]),:]
    #     scores = model.get_scores(ent,r,ent_embed,ent.shape[0]).cpu().data.numpy()
    #     test_scores[i*bs:min((i+1)*bs,test_trips.shape[0]),:] = scores
    # pdb.set_trace()
    n_batches = int(test_trips.shape[0] / bs) + 1
    allents = ents.cpu().data.numpy()
    for j in range(test_trips.shape[0]):
        print("Evaluation Phase: sample {}/{} total samples".format(j + 1,test_trips.shape[0]),end="\r")

        head_j = head[j]
        rel_j = rel[j]
        tail_j = tail[j]
        head_j = head_j.repeat(entTotal)
        rel_j = rel_j.repeat(entTotal)
        tail_j = tail_j.repeat(entTotal)

        head_sample_scores = np.zeros(entTotal)
        for i in range(n_batches):
            # print(i)
            ent_head = head_j[i * bs:min((i + 1) * bs, test_trips.shape[0])]
            # ent = ent_embed[ent, :]
            rel_i = rel_j[i * bs:min((i + 1) * bs, test_trips.shape[0])]
            # r = r_embed[r, :]
            ent_tail = allents[i * bs:min((i + 1) * bs, test_trips.shape[0])]

            head_samples = get_next_batch_test(ent_head, rel_i, ent_tail)
            head_samples = Variable(torch.from_numpy(head_samples))
            if args.use_cuda:
                head_samples = head_samples.cuda()

            head_scores = model.get_embed_my(head_samples, ents)
            head_sample_scores[i * bs:min((i + 1) * bs, test_trips.shape[0])] = head_scores.cpu().data.numpy()


        head_sample_scores = - head_sample_scores

        head_filter = []
        if (head[j], rel[j]) in ent_filter: head_filter = ent_filter[(head[j], rel[j])]

        H_r, H_h = get_rank_entity(head_sample_scores, tail[j], args.Hits, entid2clustid, head_filter)
        H_Rank.append(H_r)
        H_inv_Rank.append(1 / H_r)
        H_Hits += H_h



        tail_sample_scores = np.zeros(entTotal)
        for i in range(n_batches):
            # print(i)
            ent_head = allents[i * bs:min((i + 1) * bs, test_trips.shape[0])]
            # ent = ent_embed[ent, :]
            rel_i = rel_j[i * bs:min((i + 1) * bs, test_trips.shape[0])]
            # r = r_embed[r, :]
            ent_tail = tail_j[i * bs:min((i + 1) * bs, test_trips.shape[0])]

            tail_samples = get_next_batch_test(ent_head, rel_i, ent_tail)
            tail_samples = Variable(torch.from_numpy(tail_samples))
            if args.use_cuda:
                tail_samples = tail_samples.cuda()

            tail_scores = model.get_embed_my(tail_samples, ents)
            tail_sample_scores[i * bs:min((i + 1) * bs, test_trips.shape[0])] = tail_scores.cpu().data.numpy()


        tail_sample_scores = - tail_sample_scores

        tail_filter = []
        if (tail[j], rel[j]) in ent_filter: tail_filter = ent_filter[(tail[j], rel[j])]

        T_r, T_h = get_rank_entity(tail_sample_scores, head[j], args.Hits, entid2clustid, tail_filter)
        T_Rank.append(T_r)
        T_inv_Rank.append(1 / T_r)
        T_Hits += T_h


    print("Mean Rank: Head = {}  Tail = {}  Avg = {}"
          .format(np.mean(np.array(H_Rank)),np.mean(np.array(T_Rank)),(np.mean(np.array(H_Rank)) + np.mean(np.array(T_Rank)))/2))
    print("MRR: Head = {}  Tail = {}  Avg = {}"
          .format(np.mean(np.array(H_inv_Rank)),np.mean(np.array(T_inv_Rank)),(np.mean(np.array(H_inv_Rank)) + np.mean(np.array(T_inv_Rank)))/2))
    
    for i,hits in enumerate(args.Hits):
        print("Hits@{}: Head = {}  Tail={}  Avg = {}"
              .format(hits,H_Hits[i]/len(H_Rank),T_Hits[i]/len(H_Rank),(H_Hits[i] + T_Hits[i])/(2*len(H_Rank))))

    return (H_Hits[0] + T_Hits[0]) / (len(H_Rank)+len(T_Rank)), \
           (H_Hits[1] + T_Hits[1]) / (len(H_Rank)+len(T_Rank)), \
           (H_Hits[2] + T_Hits[2]) / (len(H_Rank)+len(T_Rank))



def evaluate_final(model, entTotal, num_rels, test_trips, args, data):
    ents = torch.arange(0, entTotal, dtype=torch.long)
    rel_id = torch.arange(0, num_rels, dtype=torch.long)
    H_Rank = []
    H_inv_Rank = []
    H_Hits = np.zeros((len(args.Hits)))

    T_Rank = []
    T_inv_Rank = []
    T_Hits = np.zeros((len(args.Hits)))

    H_Rank_mention = []
    H_inv_Rank_mention = []
    H_Hits_mention = np.zeros((len(args.Hits)))

    T_Rank_mention = []
    T_inv_Rank_mention = []
    T_Hits_mention = np.zeros((len(args.Hits)))


    H_AC_Rank = []
    H_AC_inv_Rank = []
    H_AC_Hits = np.zeros((len(args.Hits)))
    H_DC_Rank = []
    H_DC_inv_Rank = []
    H_DC_Hits = np.zeros((len(args.Hits)))
    H_DC_Rank_d = []
    H_DC_inv_Rank_d = []
    H_DC_Hits_d = np.zeros((len(args.Hits)))

    T_AC_Rank = []
    T_AC_inv_Rank = []
    T_AC_Hits = np.zeros((len(args.Hits)))
    T_DC_Rank = []
    T_DC_inv_Rank = []
    T_DC_Hits = np.zeros((len(args.Hits)))
    T_DC_Rank_d = []
    T_DC_inv_Rank_d = []
    T_DC_Hits_d = np.zeros((len(args.Hits)))


    head = test_trips[:, 0]
    rel = test_trips[:, 1]
    tail = test_trips[:, 2]
    id2ent = data.id2ent
    id2rel = data.id2rel
    true_clusts_ent = data.true_clusts
    entid2clustid = data.entid2clustid
    ent_filter = data.label_filter
    bs = args.batch_size

    if args.use_cuda:
        ents = ents.cuda()
        # rel_id = rel_id.cuda()

    # test_scores = np.zeros((test_trips.shape[0], entTotal))
    # n_batches = int(test_trips.shape[0] / bs) + 1
    # start_time = time.time()
    # for i in range(n_batches):
    #     # print(i)
    #     ent = head[i * bs:min((i + 1) * bs, test_trips.shape[0])]
    #     # ent = ent_embed[ent, :]
    #     r = rel[i * bs:min((i + 1) * bs, test_trips.shape[0])]
    #     # r = r_embed[r, :]
    #     samples = get_next_batch_test(ent, r)
    #     samples = Variable(torch.from_numpy(samples))
    #     if args.use_cuda:
    #         samples = samples.cuda()
    #         # edges_ent_batch = edges_ent_batch.cuda()
    #         # edges_rel_batch = edges_rel_batch.cuda()
    #     scores = model.get_embed_my(samples, ents)
    #     test_scores[i * bs:min((i + 1) * bs, test_trips.shape[0]), :] = scores.cpu().data.numpy()
    #
    # end_time = time.time()
    # print(end_time - start_time)

    alldelete = 0
    allents = ents.cpu().data.numpy()
    n_batches = int(test_trips.shape[0] / bs) + 1
    for j in range(test_trips.shape[0]):
        print("Evaluation Phase: sample {}/{} total samples".format(j + 1, test_trips.shape[0]), end="\r")
        # pdb.set_trace()
        head_j = head[j]
        rel_j = rel[j]
        tail_j = tail[j]
        head_j = head_j.repeat(entTotal)
        rel_j = rel_j.repeat(entTotal)
        tail_j = tail_j.repeat(entTotal)

        head_sample_scores = np.zeros(entTotal)
        for i in range(n_batches):
            # print(i)
            ent_head = head_j[i * bs:min((i + 1) * bs, test_trips.shape[0])]
            # ent = ent_embed[ent, :]
            rel_i = rel_j[i * bs:min((i + 1) * bs, test_trips.shape[0])]
            # r = r_embed[r, :]
            ent_tail = allents[i * bs:min((i + 1) * bs, test_trips.shape[0])]

            head_samples = get_next_batch_test(ent_head, rel_i, ent_tail)
            head_samples = Variable(torch.from_numpy(head_samples))
            if args.use_cuda:
                head_samples = head_samples.cuda()

            head_scores = model.get_embed_my(head_samples, ents)
            head_sample_scores[i * bs:min((i + 1) * bs, test_trips.shape[0])] = head_scores.cpu().data.numpy()

        head_sample_scores = - head_sample_scores


        # head_samples = get_next_batch_test(head_j, rel_j, allents)
        # head_samples = Variable(torch.from_numpy(head_samples))
        # if args.use_cuda:
        #     head_samples = head_samples.cuda()
        # head_scores = model.get_embed_my(head_samples, ents)
        # head_sample_scores = - head_scores.cpu().data.numpy()

        head_filter = []
        if (head[j], rel[j]) in ent_filter: head_filter = ent_filter[(head[j], rel[j])]

        H_r, H_h = get_rank_entity(head_sample_scores, tail[j], args.Hits, entid2clustid, head_filter)
        H_Rank.append(H_r)
        H_inv_Rank.append(1 / H_r)
        H_Hits += H_h

        H_t_clust_mention = set(true_clusts_ent[tail[j]])
        H_r_mention, H_h_mention = get_rank_mention(head_sample_scores, H_t_clust_mention, args.Hits, entid2clustid, head_filter)
        H_Rank_mention.append(H_r_mention)
        H_inv_Rank_mention.append(1 / H_r_mention)
        H_Hits_mention += H_h_mention

        H_t_clust_id = entid2clustid[tail[j]]
        H_AC_r, H_AC_h, H_DC_r, H_DC_h, H_DC_delete1 = get_rank_cluster(head_sample_scores, H_t_clust_id, args.Hits,
                                                                        entid2clustid, head_filter)

        H_AC_Rank.append(H_AC_r)
        H_AC_inv_Rank.append(1 / H_AC_r)
        H_AC_Hits += H_AC_h
        H_DC_Rank.append(H_DC_r)
        H_DC_inv_Rank.append(1 / (H_DC_r + 1))
        H_DC_Hits += H_DC_h

        if H_DC_delete1 is not True:
            H_DC_Rank_d.append(H_DC_r)
            H_DC_inv_Rank_d.append(1 / (H_DC_r + 1))
            H_DC_Hits_d += H_DC_h




        tail_sample_scores = np.zeros(entTotal)
        for i in range(n_batches):
            # print(i)
            ent_head = allents[i * bs:min((i + 1) * bs, test_trips.shape[0])]
            # ent = ent_embed[ent, :]
            rel_i = rel_j[i * bs:min((i + 1) * bs, test_trips.shape[0])]
            # r = r_embed[r, :]
            ent_tail = tail_j[i * bs:min((i + 1) * bs, test_trips.shape[0])]

            tail_samples = get_next_batch_test(ent_head, rel_i, ent_tail)
            tail_samples = Variable(torch.from_numpy(tail_samples))
            if args.use_cuda:
                tail_samples = tail_samples.cuda()

            tail_scores = model.get_embed_my(tail_samples, ents)
            tail_sample_scores[i * bs:min((i + 1) * bs, test_trips.shape[0])] = tail_scores.cpu().data.numpy()

        tail_sample_scores = - tail_sample_scores

        # tail_samples = get_next_batch_test(allents, rel_j, tail_j)
        # tail_samples = Variable(torch.from_numpy(tail_samples))
        # if args.use_cuda:
        #     tail_samples = tail_samples.cuda()
        # tail_scores = model.get_embed_my(tail_samples, ents)
        # tail_sample_scores = - tail_scores.cpu().data.numpy()

        tail_filter = []
        if (tail[j], rel[j]) in ent_filter: tail_filter = ent_filter[(tail[j], rel[j])]

        T_r, T_h = get_rank_entity(tail_sample_scores, head[j], args.Hits, entid2clustid, tail_filter)
        T_Rank.append(T_r)
        T_inv_Rank.append(1 / T_r)
        T_Hits += T_h

        T_t_clust_mention = set(true_clusts_ent[head[j]])
        T_r_mention, T_h_mention = get_rank_mention(tail_sample_scores, T_t_clust_mention, args.Hits, entid2clustid, tail_filter)
        T_Rank_mention.append(T_r_mention)
        T_inv_Rank_mention.append(1 / T_r_mention)
        T_Hits_mention += T_h_mention

        T_t_clust_id = entid2clustid[head[j]]
        T_AC_r, T_AC_h, T_DC_r, T_DC_h, T_DC_delete1 = get_rank_cluster(tail_sample_scores, T_t_clust_id, args.Hits,
                                                                        entid2clustid, tail_filter)

        T_AC_Rank.append(T_AC_r)
        T_AC_inv_Rank.append(1 / T_AC_r)
        T_AC_Hits += T_AC_h
        T_DC_Rank.append(T_DC_r)
        T_DC_inv_Rank.append(1 / (T_DC_r + 1))
        T_DC_Hits += T_DC_h

        if T_DC_delete1 is not True:
            T_DC_Rank_d.append(T_DC_r)
            T_DC_inv_Rank_d.append(1 / (T_DC_r + 1))
            T_DC_Hits_d += T_DC_h



    with open('result.txt', 'a', encoding='utf-8') as f:
        f.write(str(np.mean(np.array(H_Rank))) + '\t')
        f.write(str(np.mean(np.array(H_inv_Rank))) + '\t')
        for i, hits in enumerate(args.Hits):
            f.write(str(H_Hits[i] / len(H_Rank))+ '\t')
        f.write('\n')
        f.write(str(np.mean(np.array(T_Rank))) + '\t')
        f.write(str(np.mean(np.array(T_inv_Rank))) + '\t')
        for i, hits in enumerate(args.Hits):
            f.write(str(T_Hits[i] / len(T_Rank)) + '\t')
        f.write('\n')


        f.write(str(np.mean(np.array(H_Rank_mention))) + '\t')
        f.write(str(np.mean(np.array(H_inv_Rank_mention))) + '\t')
        for i, hits in enumerate(args.Hits):
            f.write(str(H_Hits_mention[i] / len(H_Rank_mention)) + '\t')
        f.write('\n')
        f.write(str(np.mean(np.array(T_Rank_mention))) + '\t')
        f.write(str(np.mean(np.array(T_inv_Rank_mention))) + '\t')
        for i, hits in enumerate(args.Hits):
            f.write(str(T_Hits_mention[i] / len(T_Rank_mention)) + '\t')
        f.write('\n')




        f.write(str(np.mean(np.array(H_AC_Rank))) + '\t')
        f.write(str(np.mean(np.array(H_AC_inv_Rank))) + '\t')
        for i, hits in enumerate(args.Hits):
            f.write(str(H_AC_Hits[i] / len(H_AC_Rank)) + '\t')
        f.write('\n')
        f.write(str(np.mean(np.array(T_AC_Rank))) + '\t')
        f.write(str(np.mean(np.array(T_AC_inv_Rank))) + '\t')
        for i, hits in enumerate(args.Hits):
            f.write(str(T_AC_Hits[i] / len(T_AC_Rank)) + '\t')
        f.write('\n')


        f.write(str(np.mean(np.array(H_DC_Rank))) + '\t')
        f.write(str(np.mean(np.array(H_DC_inv_Rank))) + '\t')
        for i, hits in enumerate(args.Hits):
            f.write(str(H_DC_Hits[i] / len(H_DC_Rank)) + '\t')
        f.write('\n')
        f.write(str(np.mean(np.array(T_DC_Rank))) + '\t')
        f.write(str(np.mean(np.array(T_DC_inv_Rank))) + '\t')
        for i, hits in enumerate(args.Hits):
            f.write(str(T_DC_Hits[i] / len(T_DC_Rank)) + '\t')
        f.write('\n')


        f.write(str(np.mean(np.array(H_DC_Rank_d))) + '\t')
        f.write(str(np.mean(np.array(H_DC_inv_Rank_d))) + '\t')
        for i, hits in enumerate(args.Hits):
            f.write(str(H_DC_Hits_d[i] / len(H_DC_Rank_d)) + '\t')
        f.write('\n')
        f.write(str(np.mean(np.array(T_DC_Rank_d))) + '\t')
        f.write(str(np.mean(np.array(T_DC_inv_Rank_d))) + '\t')
        for i, hits in enumerate(args.Hits):
            f.write(str(T_DC_Hits_d[i] / len(T_DC_Rank_d)) + '\t')
        f.write('\n')

    print(alldelete)

    return H_Hits[0] / len(H_Rank), H_Hits[1] / len(H_Rank), H_Hits[2] / len(H_Rank)
