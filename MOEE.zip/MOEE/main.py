#### Import all the supporting classes

import argparse
import numpy as np

from utils import *
from encoder import GRUEncoder
from data import load_data
from moe import MOE
import torch
import time
import pdb

import os
# os.environ["CUDA_DEVICE_ORDER"] = "PCI_BUS_ID"
# os.environ["CUDA_VISIBLE_DEVICES"] = "0"

def set_seed(seed):
    os.environ['PYTHONHASHSEED'] = str(seed)
    # dgl.seed(seed)
    # dgl.random.seed(seed)

    # random.seed(seed)
    np.random.seed(seed)
    torch.manual_seed(seed)
    torch.cuda.manual_seed(seed)
    torch.cuda.manual_seed_all(seed)
    torch.backends.cudnn.benchmark = False
    torch.backends.cudnn.deterministic = True
    # torch.use_deterministic_algorithms(True) # for other torch version
    # torch.set_deterministic(True) # for torch1.7.1

    # generator = torch.Generator()
    # generator.manual_seed(seed)
    # return generator

def only_evaluate(args):
	# data = load_data(args)
	data = torch.load('pretrained/data.pth')
	args.pad_id = data.word2id['<PAD>']
	args.num_nodes = len(data.ent2id)
	args.num_rels = len(data.rel2id)
	if torch.cuda.is_available():
		args.use_cuda = True
	else:
		args.use_cuda = False

	model_state_file = args.model_path

	model = ConvEParam(args, data.embed_matrix, data.rel2word, data.ent2word)

	if args.use_cuda:
		model.cuda()

	print("Test Set Evaluation ---")
	model = torch.load('output/best_model.pth')
	model.eval()
	temp_acc = evaluate_neg(model, args.num_nodes, args.num_rels, data.valid_trips, args, data)
	print("temp_acc {}".format(temp_acc))
	temp_acc = evaluate_neg(model, args.num_nodes, args.num_rels, data.test_trips, args, data)
	print("temp_acc {}".format(temp_acc))

	torch.save({'state_dict': model.state_dict()}, 'output/neg_best_model.pth')


def main(args, output_path):
	if torch.cuda.is_available(): args.use_cuda = True
	else: args.use_cuda = False

	data = load_data(args)
	# data = torch.load('pretrained/' + args.dataset + '/data.pth')
	# data = torch.load('pretrained/data.pth')
	# pdb.set_trace()
	print(len(data.train_trips))

	args.pad_id = data.word2id['<PAD>']
	args.num_nodes = len(data.ent2id)
	args.num_rels = len(data.rel2id)


	# model = ConvEParam(args,data.embed_matrix,data.rel2word, data.ent2word)

	model = MOE(args, data.embed_matrix, data.rel2word, data.ent2word)

	# pdb.set_trace()

	total = sum([param.nelement() for param in model.parameters()])
	print("Number of parameter: %.2fM" % (total / 1e6))
	return
	model_state_file = args.model_path

	optimizer = torch.optim.Adam(model.parameters(), lr=args.lr)
	# scheduler = torch.optim.lr_scheduler.ReduceLROnPlateau(optimizer, mode = 'max',factor = 0.5, patience = 2)

	
	# train_pairs = list(data.label_graph.keys())
	train_trips = data.train_trips

	train_id = np.arange(len(train_trips))

	node_id = torch.arange(0, args.num_nodes, dtype=torch.long)
	rel_id = torch.arange(0, args.num_rels, dtype=torch.long)
	node_id_list = set([m for m in range(args.num_nodes)])
	rel_id_list = set([m for m in range(args.num_rels)])
	# pdb.set_trace()
	if args.use_cuda:
		model = model.cuda()
		node_id = node_id.cuda()
		rel_id = rel_id.cuda()

	best_epoch = 0
	best_hit1 = 0.0
	best_hit10 = 0.0
	best_hit50 = 0.0
	count = 0
	best_acc = 0
	for epoch in range(args.n_epochs):
		model.train()
		if count >= args.early_stop: break
		epoch_loss = 0
		permute = np.random.permutation(train_id)
		train_id = train_id[permute]
		n_batches = train_id.shape[0]//args.batch_size
		# pdb.set_trace()


		for i in range(n_batches):
			# t1 = time.time()
			id_list = train_id[i*args.batch_size:(i+1)*args.batch_size]
			samples, labels, e_batch, e_len, r_batch, r_len = get_next_batch(id_list, data, args, train_trips, node_id_list, rel_id_list)

			# samples = Variable(torch.from_numpy(samples))
			# labels = Variable(torch.from_numpy(labels).float())
			# if args.use_cuda:
			# 	samples = samples.cuda()
			# 	labels = labels.cuda()

			optimizer.zero_grad()
			loss, _ = model(samples, node_id, e_batch, e_len, r_batch, r_len, labels)

			loss.backward()
			print("batch {}/{} batches, batch_loss: {}".format(i,n_batches,(loss.data).cpu().numpy()),end='\r')
			torch.nn.utils.clip_grad_norm_(model.parameters(), args.grad_norm)
			optimizer.step()
			epoch_loss += (loss.data).cpu().numpy()
			# print(time.time()-t1)

		print("epoch {}/{} total epochs, epoch_loss: {}".format(epoch+1,args.n_epochs,epoch_loss/n_batches))

		temp_acc = evaluate_neg(model, args.num_nodes, args.num_rels, data.valid_trips, args, data)
		print("temp_acc {}".format(temp_acc))

		with open(output_path + '/log.txt', 'a', encoding='utf-8') as f:
			f.write(str(args.n_epochs) + '\t' + str(epoch_loss/n_batches) + '\t' + str(temp_acc) + '\n')

		if temp_acc > best_acc:
			best_acc = temp_acc
			best_epoch = epoch
			# torch.save(model, 'output/best_model.pth')
			torch.save({'state_dict': model.state_dict()}, output_path + '/neg_best_model.pth')
			torch.save(data, output_path + '/data.pth')
			torch.save(optimizer, output_path + '/optimizer.pth')
			count = 0
		else:
			count +=1

		print("Best acc: {}, Best epoch: {}".format(best_acc, best_epoch))



	### Get Embeddings
	# print("Test Set Evaluation ---")
	# # checkpoint = torch.load(model_state_file)
	# # model.eval()
	# # model.load_state_dict(checkpoint['state_dict'])
	# model = torch.load('output/best_model.pth')
	# model.eval()
	# _,_,_ = evaluate_final(model, args.num_nodes, args.num_rels, data.test_trips, args, data)




if __name__ == '__main__':
	parser = argparse.ArgumentParser(description='CaRe: Canonicalization Infused Representations for Open KGs')

	### Model and Dataset choice
	parser.add_argument('-CN',   dest='CN', default='LAN', choices=['LAN','GCN','GAT','Phi'], help='Choice of Canonical Cluster Encoder Network')
	parser.add_argument('-dataset', 	    dest='dataset', 	    default='ReVerb45K', help='Dataset Choice')

	### Data Paths
	parser.add_argument('-data_path',       dest='data_path',       default='../../Data', 			help='Data folder')

	#### Hyper-parameters
	parser.add_argument('-nfeats',      dest='nfeats',       default=300,   type=int,       help='Embedding Dimensions')
	parser.add_argument('-nheads',      dest='nheads',       default=3,     type=int,       help='multi-head attantion in GAT')
	parser.add_argument('-num_layers',  dest='num_layers',   default=1,     type=int,       help='No. of layers in encoder network')
	parser.add_argument('-bidirectional',  dest='bidirectional',   default=True,     type=bool,       help='type of encoder network')
	parser.add_argument('-poolType',    dest='poolType',     default='last',choices=['last','max','mean'], help='pooling operation for encoder network')
	parser.add_argument('-dropout',     dest='dropout',      default=0.5,   type=float,     help='Dropout')
	parser.add_argument('-reg_param',   dest='reg_param',    default=0.0,   type=float,     help='regularization parameter')
	parser.add_argument('-lr',          dest='lr',           default=0.00005, type=float,     help='learning rate')
	parser.add_argument('-p_norm',      dest='p_norm',       default=1,     type=int,       help='TransE scoring function')
	parser.add_argument('-batch_size',  dest='batch_size',   default=128,   type=int,       help='batch size for training')
	parser.add_argument('-neg_samples', dest='neg_samples',  default=50,    type=int,       help='No of Negative Samples for TransE')
	parser.add_argument('-rel_neg_samples', dest='rel_neg_samples',  default=10,    type=int,		help='No of Negative Samples for TransE')
	parser.add_argument('-n_epochs',    dest='n_epochs',     default=1000,   type=int,       help='maximum no. of epochs')
	parser.add_argument('-grad_norm',   dest='grad_norm',    default=1.0,   type=float,     help='gradient clipping')
	parser.add_argument('-eval_epoch',  dest='eval_epoch',   default=1,     type=int,       help='Interval for evaluating on validation dataset')
	parser.add_argument('-Hits',        dest='Hits',         default= [1,10,50,100],           help='Choice of n in Hits@n')
	parser.add_argument('-early_stop',  dest='early_stop',   default=10,    type=int,       help='Stopping training after validation performance stops improving')
	parser.add_argument('-my', dest='my', default=True, type=bool)
	parser.add_argument('-temp', dest='temp', default=0.05, type=float, help='temp for cl')
	parser.add_argument('-seed', default=1234, type=int)

	parser.add_argument("--kge", type=str, default="MOE", help="ConvE, TransE, DistMult, ComplEx, RotatE")
	parser.add_argument('--temp', dest='temp', default=0.05, type=float, help='temp for cl')
	parser.add_argument('--num_experts', default=4, type=int)
	parser.add_argument('--top_k', default=2, type=int)
	parser.add_argument('--gamma', default=10, type=float)

	args = parser.parse_args()


	args.data_files = {
	'ent2id_path'       : args.data_path + '/' + args.dataset + '/ent2id.txt',
	'rel2id_path'       : args.data_path + '/' + args.dataset + '/rel2id.txt',
	'train_trip_path'   : args.data_path + '/' + args.dataset + '/train_trip.txt',
	'test_trip_path'    : args.data_path + '/' + args.dataset + '/test_trip.txt',
	'valid_trip_path'   : args.data_path + '/' + args.dataset + '/valid_trip.txt',
	'gold_npclust_path' : args.data_path + '/' + args.dataset + '/gold_npclust.txt',
	'glove_path'        :  args.data_path + '/glove/glove.6B.300d.txt',
	'sd_kgtext2okgtext_ent': args.data_path + '/' + args.dataset +'/syn/sd_kgtext2okgtext_ent.json'
	}

	args.model_path = "ConvE" + "-" + args.CN + "_modelpath.pth"

	set_seed(args.seed)
	output_path = 'output/' + args.dataset + '/' + args.kge
	if not os.path.exists(output_path):
		os.makedirs(output_path)

	print(output_path)
	print(args.kge)
	print(args.top_k)
	main(args, output_path)
	# only_evaluate(args)
