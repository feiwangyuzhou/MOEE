import torch
import torch.nn as nn
import torch.nn.functional as F
import pdb
class TopkRouter(torch.nn.Module):
    def __init__(self, n_embed, num_experts, top_k):
        super(TopkRouter, self).__init__()
        self.top_k = top_k
        self.linear = nn.Linear(n_embed*2, num_experts)

    def forward(self, sub_embed, rel_embed):
        hr_output = torch.cat([sub_embed, rel_embed], dim=1)
        logits = self.linear(hr_output)
        top_k_logits, indices = logits.topk(self.top_k, dim=-1)
        zeros = torch.full_like(logits, float('-inf'))
        sparse_logits = zeros.scatter(-1, indices, top_k_logits)
        router_output = F.softmax(sparse_logits, dim=-1)
        return router_output, indices


class NoisyTopkRouter(torch.nn.Module):
    def __init__(self, n_embed, num_experts, top_k):
        super(NoisyTopkRouter, self).__init__()
        self.top_k = top_k
        self.topkroute_linear = nn.Linear(n_embed*2, num_experts)
        # add noise
        self.noise_linear = nn.Linear(n_embed*2, num_experts)

    def forward(self, sub_embed, rel_embed):
        # pdb.set_trace()
        hr_output = torch.cat([sub_embed, rel_embed], dim=1)
        logits = self.topkroute_linear(hr_output)

        # Noise logits
        noise_logits = self.noise_linear(hr_output)
        noise = torch.randn_like(logits) * F.softplus(noise_logits)
        noisy_logits = logits + noise

        top_k_logits, indices = noisy_logits.topk(self.top_k, dim=-1)
        zeros = torch.full_like(noisy_logits, float('-inf'))
        sparse_logits = zeros.scatter(-1, indices, top_k_logits)
        router_output = F.softmax(sparse_logits, dim=-1)
        return router_output, indices



class NoisyTopkRouter2(torch.nn.Module):
    def __init__(self, n_embed, num_experts, top_k):
        super(NoisyTopkRouter2, self).__init__()
        self.top_k = top_k
        self.topkroute_linear_head = nn.Linear(n_embed, num_experts)
        self.topkroute_linear_rel = nn.Linear(n_embed, num_experts)
        # add noise
        self.noise_linear = nn.Linear(n_embed, num_experts)

    def forward(self, sub_embed, rel_embed):
        # pdb.set_trace()
        logits_head = self.topkroute_linear_head(sub_embed)
        logits_rel = self.topkroute_linear_rel(rel_embed)

        # Noise logits
        noise_logits_head = self.noise_linear(sub_embed)
        noise_logits_rel = self.noise_linear(rel_embed)
        noise_head = torch.randn_like(logits_head) * F.softplus(noise_logits_head)
        noise_rel = torch.randn_like(logits_rel) * F.softplus(noise_logits_rel)
        noisy_logits = logits_head + logits_rel + noise_head + noise_rel

        top_k_logits, indices = noisy_logits.topk(self.top_k, dim=-1)
        zeros = torch.full_like(noisy_logits, float('-inf'))
        sparse_logits = zeros.scatter(-1, indices, top_k_logits)
        router_output = F.softmax(sparse_logits, dim=-1)
        return router_output, indices


class Attention_router(nn.Module):
    def __init__(self, n_embed, num_experts, top_k):
        super(Attention_router, self).__init__()
        self.top_k = top_k

        self.query = nn.Linear(n_embed*2, num_experts, bias=False)
        self.key = nn.Linear(n_embed*2, num_experts, bias=False)
        self.value = nn.Linear(n_embed*2, num_experts, bias=False)

    def forward(self, sub_embed, rel_embed):
        # pdb.set_trace()
        hidden_states = torch.cat([sub_embed, rel_embed], dim=1)
        query_layer = self.query(hidden_states)
        key_layer = self.key(hidden_states)
        value_layer = self.value(hidden_states)

        b = query_layer.size(0)
        s = query_layer.size(1)  # expert_num

        query_layer = query_layer.float().view(b, s, 1)
        key_layer = key_layer.float().view(b, s, 1)
        value_layer = value_layer.float().view(b, s, 1)

        attn_weights = torch.matmul(query_layer, key_layer.transpose(1, 2))
        attn_weights = nn.functional.softmax(attn_weights, dim=-1)

        attn_output = torch.matmul(attn_weights, value_layer)

        attn_output = attn_output.view(b, s)

        top_k_logits, indices = attn_output.topk(self.top_k, dim=-1)
        zeros = torch.full_like(attn_output, float('-inf'))
        sparse_logits = zeros.scatter(-1, indices, top_k_logits)
        router_output = F.softmax(sparse_logits, dim=-1)

        return router_output, indices


class NoisyAttention_router(nn.Module):
    def __init__(self, n_embed, num_experts, top_k):
        super(NoisyAttention_router, self).__init__()
        self.top_k = top_k

        self.query = nn.Linear(n_embed*2, num_experts, bias=False)
        self.key = nn.Linear(n_embed*2, num_experts, bias=False)
        self.value = nn.Linear(n_embed*2, num_experts, bias=False)

        self.noise_linear = nn.Linear(n_embed * 2, num_experts)

    def forward(self, sub_embed, rel_embed):
        # pdb.set_trace()
        hidden_states = torch.cat([sub_embed, rel_embed], dim=1)
        query_layer = self.query(hidden_states)
        key_layer = self.key(hidden_states)
        value_layer = self.value(hidden_states)

        b = query_layer.size(0)
        s = query_layer.size(1)  # expert_num

        # use fp32 router
        query_layer = query_layer.float().view(b, s, 1)
        key_layer = key_layer.float().view(b, s, 1)
        value_layer = value_layer.float().view(b, s, 1)

        attn_weights = torch.matmul(query_layer, key_layer.transpose(1, 2))
        attn_weights = nn.functional.softmax(attn_weights, dim=-1)

        attn_output = torch.matmul(attn_weights, value_layer)

        attn_output = attn_output.view(b, s)

        # Noise logits
        noise_logits = self.noise_linear(hidden_states)
        # Adding scaled unit gaussian noise to the logits
        noise = torch.randn_like(attn_output) * F.softplus(noise_logits)
        attn_output = attn_output + noise

        top_k_logits, indices = attn_output.topk(self.top_k, dim=-1)
        zeros = torch.full_like(attn_output, float('-inf'))
        sparse_logits = zeros.scatter(-1, indices, top_k_logits)
        router_output = F.softmax(sparse_logits, dim=-1)

        return router_output, indices


class NoisyAttention_router2(nn.Module):
    def __init__(self, n_embed, num_experts, top_k):
        super(NoisyAttention_router2, self).__init__()
        self.top_k = top_k

        self.query = nn.Linear(n_embed, num_experts, bias=False)
        self.key = nn.Linear(n_embed, num_experts, bias=False)
        self.value = nn.Linear(n_embed*2, num_experts, bias=False)

        self.noise_linear = nn.Linear(n_embed * 2, num_experts)

    def forward(self, sub_embed, rel_embed):
        # pdb.set_trace()
        hidden_states = torch.cat([sub_embed, rel_embed], dim=1)
        query_layer = self.query(sub_embed)
        key_layer = self.key(rel_embed)
        value_layer = self.value(hidden_states)

        b = query_layer.size(0)
        s = query_layer.size(1)  # expert_num

        # use fp32 router
        query_layer = query_layer.float().view(b, s, 1)
        key_layer = key_layer.float().view(b, s, 1)
        value_layer = value_layer.float().view(b, s, 1)

        attn_weights = torch.matmul(query_layer, key_layer.transpose(1, 2))
        attn_weights = nn.functional.softmax(attn_weights, dim=-1)

        attn_output = torch.matmul(attn_weights, value_layer)

        attn_output = attn_output.view(b, s)

        # Noise logits
        noise_logits = self.noise_linear(hidden_states)
        noise = torch.randn_like(attn_output) * F.softplus(noise_logits)
        attn_output = attn_output + noise

        top_k_logits, indices = attn_output.topk(self.top_k, dim=-1)
        zeros = torch.full_like(attn_output, float('-inf'))
        sparse_logits = zeros.scatter(-1, indices, top_k_logits)
        router_output = F.softmax(sparse_logits, dim=-1)

        return router_output, indices