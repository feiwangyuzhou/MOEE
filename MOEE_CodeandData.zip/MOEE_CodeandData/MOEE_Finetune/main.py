#### Import all the supporting classes

import argparse
import numpy as np

from utils import *
from encoder import GRUEncoder
from data import load_data
# from models import ConvE, TransE, DistMult, ComplEx, RotatE
from models.ConvE import ConvE
from models.TransE import TransE
from models.ComplEx import ComplEx
from models.DistMult import DistMult
from moe import MOE
import torch
import time
import pdb

import os
# os.environ["CUDA_VISIBLE_DEVICES"] = "0"


def set_seed(seed):
    os.environ['PYTHONHASHSEED'] = str(seed)
    # dgl.seed(seed)
    # dgl.random.seed(seed)

    # random.seed(seed)
    np.random.seed(seed)
    torch.manual_seed(seed)
    torch.cuda.manual_seed(seed)
    torch.cuda.manual_seed_all(seed)
    torch.backends.cudnn.benchmark = False
    torch.backends.cudnn.deterministic = True
    # torch.use_deterministic_algorithms(True) # for other torch version
    # torch.set_deterministic(True) # for torch1.7.1

    # generator = torch.Generator()
    # generator.manual_seed(seed)
    # return generator

def evaluate_onlykge(args, output_path):
	data = torch.load(output_path + '/data.pth')
	args.pad_id = data.word2id['<PAD>']
	args.num_nodes = len(data.ent2id)
	args.num_rels = len(data.rel2id)
	if torch.cuda.is_available():
		args.use_cuda = True
	else:
		args.use_cuda = False

	model = torch.load(output_path + '/best_model.pth')
	if args.use_cuda:
		model.cuda()
	model.eval()
	evaluate_final(model, args.num_nodes, args.num_rels, data.test_trips, args, data, output_path)


def evaluate_relationtype(args, output_path):
	data = torch.load(output_path + '/data.pth')
	args.pad_id = data.word2id['<PAD>']
	args.num_nodes = len(data.ent2id)
	args.num_rels = len(data.rel2id)
	if torch.cuda.is_available():
		args.use_cuda = True
	else:
		args.use_cuda = False

	relid2type = data.get_relation_type(args.data_files['rel2type_path'], data.rel2id)
	test1_1, test1_M, testM_1, testM_M = data.get_test_triples_reltype(data.test_trips, relid2type)

	print(len(data.test_trips))
	print(str(len(test1_1)+len(test1_M)+len(testM_1)+len(testM_M)))
	print("************")
	print(len(test1_1))
	print(len(test1_M))
	print(len(testM_1))
	print(len(testM_M))

	model = torch.load(output_path + '/best_model.pth')
	if args.use_cuda:
		model.cuda()
	model.eval()
	evaluate_final(model, args.num_nodes, args.num_rels, test1_1, args, data, output_path)
	evaluate_final(model, args.num_nodes, args.num_rels, test1_M, args, data, output_path)
	evaluate_final(model, args.num_nodes, args.num_rels, testM_1, args, data, output_path)
	evaluate_final(model, args.num_nodes, args.num_rels, testM_M, args, data, output_path)


def main(args, output_path):
	# data = torch.load('pretrained/' + args.dataset + '/data.pth')
	# self_triples = data.get_self_triples(data.id2ent, data.rel2id)
	# data.train_trips, data.label_graph, data.label_graph_rel = data.get_train_triples(
	# 	args.data_files["train_trip_path"],
	# 	data.entid2clustid, data.rel2id,
	# 	data.id2rel, self_triples)
	data = load_data(args)
	args.pad_id = data.word2id['<PAD>']
	args.num_nodes = len(data.ent2id)
	args.num_rels = len(data.rel2id)
	if torch.cuda.is_available(): args.use_cuda = True
	else: args.use_cuda = False

	model_func = {
		'ConvE': ConvE,
		'TransE': TransE,
		'DistMult': DistMult,
		'ComplEx': ComplEx
	}

	# pdb.set_trace()

	if args.kge in model_func:
		model = model_func[args.kge](args, data.embed_matrix, data.rel2word, data.ent2word)
	else:
		model = MOE(args,data.embed_matrix,data.rel2word, data.ent2word)
	if args.use_cuda:
		model.cuda()

	# total = sum([param.nelement() for param in model.parameters()])
	# print("Number of parameter: %.2fM" % (total / 1e6))
	# return


	if args.PT:
		model_dict = model.state_dict()
		load_pretrained_dict = torch.load('pretrained/' + args.dataset + '/'+ args.kge + '/neg_best_model.pth')
		load_pretrained_dict = load_pretrained_dict['state_dict']

		pretrained_dict = {k: v for k, v in load_pretrained_dict.items() if k in model_dict}

		model_dict.update(pretrained_dict)
		model.load_state_dict(model_dict)
		model.eval()
		evaluate(model, args.num_nodes, args.num_rels, data.valid_trips, args, data)
		evaluate(model, args.num_nodes, args.num_rels, data.test_trips, args, data)

	optimizer = torch.optim.Adam(model.parameters(), lr=args.lr)
	# scheduler = torch.optim.lr_scheduler.ReduceLROnPlateau(optimizer, mode = 'max',factor = 0.5, patience = 2)

	train_pairs = list(data.label_graph.keys())
	train_id = np.arange(len(train_pairs))

	node_id = torch.arange(0, args.num_nodes, dtype=torch.long)
	rel_id = torch.arange(0, args.num_rels, dtype=torch.long)
	if args.use_cuda:
		node_id = node_id.cuda()

	best_epoch = 0
	best_hit1 = 0.0
	best_hit10 = 0.0
	best_hit50 = 0.0
	count = 0
	for epoch in range(args.n_epochs):
		model.train()
		if count >= args.early_stop: break
		epoch_loss = 0
		permute = np.random.permutation(train_id)
		train_id = train_id[permute]
		n_batches = train_id.shape[0]//args.batch_size

		for i in range(n_batches):
			id_list = train_id[i*args.batch_size:(i+1)*args.batch_size]
			samples,labels, e_batch, e_len, r_batch, r_len = get_next_batch(id_list, data, args, train_pairs)

			samples = Variable(torch.from_numpy(samples))
			labels = Variable(torch.from_numpy(labels).float())
			if args.use_cuda:
				samples = samples.cuda()
				labels = labels.cuda()

			optimizer.zero_grad()
			loss = model(samples, node_id, e_batch, e_len, r_batch, r_len, labels)

			loss.backward()
			print("batch {}/{} batches, batch_loss: {}".format(i,n_batches,(loss.data).cpu().numpy()),end='\r')
			torch.nn.utils.clip_grad_norm_(model.parameters(), args.grad_norm)
			optimizer.step()
			epoch_loss += (loss.data).cpu().numpy()
		print("epoch {}/{} total epochs, epoch_loss: {}".format(epoch+1,args.n_epochs,epoch_loss/n_batches))

		if epoch > -1:
			if (epoch + 1)%args.eval_epoch==0:
				model.eval()
				hit1, hit10, hit50, AR, ARR, H_Hits, T_Hits, rank_num = evaluate(model, args.num_nodes, args.num_rels, data.valid_trips, args, data)
				# pdb.set_trace()
				if hit1 > best_hit1:
					count = 0
				elif (hit1 == best_hit1) and (hit10 > best_hit10):
					count = 0
				elif (hit1 == best_hit1) and (hit10 == best_hit10) and (hit50 > best_hit50):
					count = 0
				else:
					count += 1

				if count == 0:
					best_hit1 = hit1
					best_hit10 = hit10
					best_hit50 = hit50
					best_epoch = epoch

					torch.save(model, output_path + '/best_model.pth')
					torch.save(data, output_path + '/data.pth')
					torch.save(optimizer, output_path + '/optimizer.pth')
				# torch.save({'state_dict': model.state_dict(), 'epoch': epoch}, 'output/best_model.pth')

				print("Best hit1: {}, Best epoch: {}".format(best_hit1, best_epoch))

				with open(output_path + '/log.txt', 'a', encoding='utf-8') as f:
					f.write(str(epoch+1) + '\t' + str(epoch_loss / n_batches) + '\t' + str(AR) + '\t' + str(ARR))
					for i, hits in enumerate(args.Hits):
						f.write('\t' + str((H_Hits[i] + T_Hits[i]) / rank_num))
					f.write('\n')

			# scheduler.step(best_epoch)


	### Get Embeddings
	print("Test Set Evaluation ---")
	model = torch.load(output_path + '/best_model.pth')
	model.eval()
	evaluate_final(model, args.num_nodes, args.num_rels, data.test_trips, args, data, output_path)



if __name__ == '__main__':
	parser = argparse.ArgumentParser(description='TernaryCl')

	### Dataset choice
	parser.add_argument('-dataset', 	    dest='dataset', 	    default='ReVerb45K', help='Dataset Choice')

	### Data Paths
	parser.add_argument('-data_path',       dest='data_path',       default='../../Data', 			help='Data folder')

	#### Hyper-parameters
	parser.add_argument('-nfeats',      dest='nfeats',       default=300,   type=int,       help='Embedding Dimensions')
	parser.add_argument('-nheads',      dest='nheads',       default=3,     type=int,       help='multi-head attantion in GAT')
	parser.add_argument('-num_layers',  dest='num_layers',   default=1,     type=int,       help='No. of layers in encoder network')
	parser.add_argument('-bidirectional',  dest='bidirectional',   default=True,     type=bool,       help='type of encoder network')
	parser.add_argument('-poolType',    dest='poolType',     default='last',choices=['last','max','mean'], help='pooling operation for encoder network')
	parser.add_argument('-dropout',     dest='dropout',      default=0.5,   type=float,     help='Dropout')
	parser.add_argument('-reg_param',   dest='reg_param',    default=0.0,   type=float,     help='regularization parameter')
	parser.add_argument('-lr',          dest='lr',           default=0.00005, type=float,     help='learning rate')
	parser.add_argument('-p_norm',      dest='p_norm',       default=1,     type=int,       help='TransE scoring function')
	parser.add_argument('-batch_size',  dest='batch_size',   default=128,   type=int,       help='batch size for training')
	parser.add_argument('-neg_samples', dest='neg_samples',  default=10,    type=int,       help='No of Negative Samples for TransE')
	parser.add_argument('-n_epochs',    dest='n_epochs',     default=500,   type=int,       help='maximum no. of epochs')
	parser.add_argument('-grad_norm',   dest='grad_norm',    default=1.0,   type=float,     help='gradient clipping')
	parser.add_argument('-eval_epoch',  dest='eval_epoch',   default=1,     type=int,       help='Interval for evaluating on validation dataset')
	parser.add_argument('-Hits',        dest='Hits',         default= [1,3,5,10,15,20,25,30,50,70,100],           help='Choice of n in Hits@n')
	parser.add_argument('-early_stop',  dest='early_stop',   default=50,    type=int,       help='Stopping training after validation performance stops improving')
	parser.add_argument('-my', dest='my', default=True, type=bool)
	parser.add_argument('--gamma', default=10, type=float)
	parser.add_argument('-seed', default=1234, type=int)

	parser.add_argument("--LLMname", type=str, default="llama3", help="llama3, ChatGPT")
	parser.add_argument("--LLMtype", type=str, default=None)
	parser.add_argument("--kge", type=str, default="MOE", help="ConvE, TransE, DistMult, ComplEx, RotatE")
	parser.add_argument('--temp', dest='temp', default=0.05, type=float, help='temp for cl')
	parser.add_argument('--num_experts', default=4, type=int)
	parser.add_argument('--top_k', default=2, type=int)
	parser.add_argument('--PT', dest='PT', default=False, type=bool)
	parser.add_argument('--headcatrel', dest='headcatrel', default="True", type=str)

	args = parser.parse_args()


	args.data_files = {
	'ent2id_path'       : args.data_path + '/' + args.dataset + '/ent2id.txt',
	'rel2id_path'       : args.data_path + '/' + args.dataset + '/rel2id.txt',
	'rel2type_path'     : args.data_path + '/' + args.dataset + '/rel2type.txt',
	'train_trip_path'   : args.data_path + '/' + args.dataset + '/train_trip.txt',
	'test_trip_path'    : args.data_path + '/' + args.dataset + '/test_trip.txt',
	'valid_trip_path'   : args.data_path + '/' + args.dataset + '/valid_trip.txt',
	'gold_npclust_path' : args.data_path + '/' + args.dataset + '/gold_npclust.txt',
	'glove_path'        : args.data_path + '/glove/glove.6B.300d.txt'
	}


	set_seed(args.seed)
	output_path = 'output/' + args.dataset + '/'+ args.kge
	if not os.path.exists(output_path):
		os.makedirs(output_path)

	print(args.kge)
	print(args.PT)
	print(args.top_k)
	print(args.headcatrel)
	main(args, output_path)
	# evaluate_onlykge(args, output_path)
	# evaluate_withLLM(args)
	# evaluate_relationtype(args, output_path)
