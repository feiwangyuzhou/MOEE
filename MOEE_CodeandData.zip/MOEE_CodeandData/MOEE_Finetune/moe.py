from utils import *
from encoder import GRUEncoder
import torch.nn.functional as F
import torch
import time
import pdb

from models.ConvE import ConvE
from models.TransE import TransE
from models.ComplEx import ComplEx
from models.DistMult import DistMult

from TopkRouter import NoisyTopkRouter, NoisyTopkRouter2, NoisyAttention_router, NoisyAttention_router2

class MOE(torch.nn.Module):
	def __init__(self, args, embed_matrix,rel2word, ent2word=None):
		super(MOE, self).__init__()
		self.args = args
		self.phrase_embed_model = GRUEncoder(embed_matrix, self.args)
		self.np_embeddings = torch.nn.Embedding(self.args.num_nodes, self.args.nfeats)
		torch.nn.init.xavier_normal_(self.np_embeddings.weight.data)

		self.top_k = self.args.top_k
		if 'MOE' in args.kge:
			if args.headcatrel == 'True':
				self.router = NoisyTopkRouter(self.args.nfeats, self.args.num_experts, self.top_k)
			else:
				print("NoisyTopkRouter2")
				self.router = NoisyTopkRouter2(self.args.nfeats, self.args.num_experts, self.top_k)
		elif 'Attention' in args.kge:
			if args.headcatrel=='True':
				print("NoisyAttention_router")
				self.router = NoisyAttention_router(self.args.nfeats, self.args.num_experts, self.top_k)
			else:
				self.router = NoisyAttention_router2(self.args.nfeats, self.args.num_experts, self.top_k)
				print("NoisyAttention_router2")

		model_func = {
			0: ConvE,
			1: TransE,
			2: DistMult,
			3: ComplEx
		}
		self.experts = nn.ModuleList()
		for i in range(self.args.num_experts):
			# pdb.set_trace()
			expert = model_func[i%4](args, embed_matrix, rel2word, ent2word)
			self.experts.append(expert)
		# pdb.set_trace()
		# self.conve = ConvE(args, embed_matrix, rel2word, ent2word)
		# self.transe = TransE(args, embed_matrix, rel2word, ent2word)
		# self.distmult = DistMult(args, embed_matrix, rel2word, ent2word)
		# self.complex = ComplEx(args, embed_matrix, rel2word, ent2word)
		# self.rotate = RotatE(args, embed_matrix, rel2word, ent2word)
		#
		# self.experts = nn.ModuleList([Expert(n_embed) for _ in range(num_experts)])


		self.loss = torch.nn.BCELoss()

	def forward(self, samples, node_id, e_batch, e_len, r_batch, r_len, labels):
		pred = self.get_embed_my(samples, node_id, e_batch, e_len, r_batch, r_len)
		# pdb.set_trace()
		pred = F.sigmoid(pred)
		predict_loss = self.loss(pred, labels)
		# conve_score = self.conve.get_embed_my(samples, node_id, e_batch, e_len, r_batch, r_len)
		# transe_score = self.transe.get_embed_my(samples, node_id, e_batch, e_len, r_batch, r_len)
		# distmult_score = self.distmult.get_embed_my(samples, node_id, e_batch, e_len, r_batch, r_len)
		# complex_score = self.complex.get_embed_my(samples, node_id, e_batch, e_len, r_batch, r_len)
		# rotate_score = self.rotate.get_embed_my(samples, node_id, e_batch, e_len, r_batch, r_len)

		# pdb.set_trace()
		# conve_score = F.sigmoid(conve_score)
		# transe_score = F.sigmoid(transe_score)
		# distmult_score = F.sigmoid(distmult_score)
		# complex_score = F.sigmoid(complex_score)
		# rotate_score = F.sigmoid(rotate_score)

		# pred = (conve_score + transe_score + distmult_score + complex_score + rotate_score) / 5

		return predict_loss


	def get_embed_my(self, samples, node_id, e_batch, e_len, r_batch, r_len):
		np_embed = self.np_embeddings(node_id)
		np_embed_batch = self.phrase_embed_model(e_batch, e_len)
		rp_embed_batch = self.phrase_embed_model(r_batch, r_len)
		sub_embed = np_embed[samples[:, 0]]
		sub_embed = sub_embed + np_embed_batch
		rel_embed = rp_embed_batch

		# sub_embed, rel_embed, np_embed = self.get_embed_my(samples, node_id, e_batch, e_len, r_batch, r_len)
		gating_output, indices = self.router(sub_embed, rel_embed)

		# pdb.set_trace()
		score_list = []
		for i, expert in enumerate(self.experts):
			score_i = expert.get_embed_my(samples, node_id, e_batch, e_len, r_batch, r_len,
										  sub_embed, rel_embed, np_embed)
			# score_i = F.sigmoid(score_i)
			score_list.append(score_i)

		# pdb.set_trace()
		final_score = torch.stack(score_list, dim=0)
		final_score = torch.transpose(final_score, 0, 1)

		final_score = final_score * (gating_output.unsqueeze(-1))
		# final_score = final_score * gating_output
		final_score = torch.sum(final_score, dim=1)

		return final_score

	# def get_loss_my(self, samples, labels, node_id, e_batch, e_len, r_batch, r_len):
	# 	pred= self.get_embed_my(samples, node_id, e_batch, e_len, r_batch, r_len)
	# 	# pred = F.sigmoid(scores)
	# 	predict_loss = self.loss(pred, labels)
	#
	# 	return predict_loss