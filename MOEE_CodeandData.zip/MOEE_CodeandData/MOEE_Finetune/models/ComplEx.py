from utils import *
from encoder import GRUEncoder
import torch.nn.functional as F
import torch
import time


class ComplEx(torch.nn.Module):
	def __init__(self, args, embed_matrix,rel2words, ent2word=None):
		super(ComplEx, self).__init__()
		self.args = args

		self.rel2words = rel2words
		self.ent2word = ent2word
		self.phrase_embed_model = GRUEncoder(embed_matrix, self.args)

		self.np_embeddings = torch.nn.Embedding(self.args.num_nodes, self.args.nfeats)
		torch.nn.init.xavier_normal_(self.np_embeddings.weight.data)
		# self.rp_embeddings = torch.nn.Embedding(self.args.num_rels, self.args.nfeats)
		# torch.nn.init.xavier_normal_(self.rp_embeddings.weight.data)

		# self.gamma = torch.Tensor([args.gamma])
		# self.epsilon = 2.0
		# self.embedding_range = torch.Tensor([(self.gamma.item() + self.epsilon) / self.args.nfeats])

		# self.inp_drop = torch.nn.Dropout(self.args.dropout)
		# self.hidden_drop = torch.nn.Dropout(self.args.dropout)
		# self.feature_map_drop = torch.nn.Dropout2d(self.args.dropout)
		# self.loss = torch.nn.BCELoss()
		#
		# self.conv1 = torch.nn.Conv2d(1, 32, (3, 3))
		# self.bn0 = torch.nn.BatchNorm2d(1)
		# self.bn1 = torch.nn.BatchNorm2d(32)
		# self.bn2 = torch.nn.BatchNorm1d(self.args.nfeats)
		# self.register_parameter('b', torch.nn.Parameter(torch.zeros(self.args.num_nodes)))
		# self.fc = torch.nn.Linear(self.args.nfeats, self.args.nfeats*2)

	def forward(self, samples, node_id, e_batch, e_len, r_batch, r_len, labels):
		scores = self.get_embed_my(samples, node_id, e_batch, e_len, r_batch, r_len)
		pred = F.sigmoid(scores)

		predict_loss = self.loss(pred, labels)

		return predict_loss

	def get_scores(self,ent,rel,ent_embed,batch_size):
		# pdb.set_trace()
		# head = ent.unsqueeze(1)
		# relation = rel.unsqueeze(1)
		# tail = ent_embed.unsqueeze(0)
		# re_head, im_head = torch.chunk(head, 2, dim=2)
		# re_relation, im_relation = torch.chunk(relation, 2, dim=2)
		# re_tail, im_tail = torch.chunk(tail, 2, dim=2)
		#
		# # if mode == 'head-batch':
		# # 	re_score = re_relation * re_tail + im_relation * im_tail
		# # 	im_score = re_relation * im_tail - im_relation * re_tail
		# # 	score = re_head * re_score + im_head * im_score
		# # else:
		# re_score = re_head * re_relation - im_head * im_relation
		# im_score = re_head * im_relation + im_head * re_relation
		# score = re_score * re_tail + im_score * im_tail
		#
		# score = score.sum(dim=2)

		re_head, im_head = torch.chunk(ent, 2, dim=1)
		re_relation, im_relation = torch.chunk(rel, 2, dim=1)
		# re_tail, im_tail = torch.chunk(tail_embed, 2, dim=1)

		re_score = re_head * re_relation - im_head * im_relation
		im_score = re_head * im_relation + im_head * re_relation
		score = torch.cat((re_score,im_score), dim=1)
		score = torch.mm(score, ent_embed.transpose(1, 0))

		return score

	def get_embed_my(self, samples, node_id, e_batch, e_len, r_batch, r_len, sub_embed_base, rel_embed_base, np_embed_base):

		np_embed = self.np_embeddings(node_id)
		np_embed_batch = self.phrase_embed_model(e_batch, e_len)

		rp_embed_batch = self.phrase_embed_model(r_batch, r_len)

		sub_embed = np_embed[samples[:, 0]]
		# pdb.set_trace()
		# np_embed_batch = self.fc(np_embed_batch)
		sub_embed = sub_embed + np_embed_batch
		rel_embed = rp_embed_batch

		sub_embed = torch.cat([sub_embed, sub_embed_base], dim=1)
		rel_embed = torch.cat([rel_embed, rel_embed_base], dim=1)
		np_embed = torch.cat([np_embed, np_embed_base], dim=1)

		scores = self.get_scores(sub_embed, rel_embed, np_embed, len(samples))

		return scores

	# def get_loss_my(self, samples, labels, node_id, e_batch, e_len, r_batch, r_len):
	# 	# pdb.set_trace()
	# 	scores= self.get_embed_my(samples, node_id, e_batch, e_len, r_batch, r_len)
	# 	pred = F.sigmoid(scores)
	#
	# 	predict_loss = self.loss(pred, labels)
	#
	# 	return predict_loss