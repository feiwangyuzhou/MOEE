from utils import *
from encoder import GRUEncoder
import torch.nn.functional as F
import torch
import torch.nn as nn
import time
import pdb

from collections import OrderedDict

class Similarity(nn.Module):
	"""
	Dot product or cosine similarity
	"""

	def __init__(self, temp):
		super().__init__()
		self.temp = temp
		self.cos = nn.CosineSimilarity(dim=-1)

	def forward(self, x, y):
		return self.cos(x, y) / self.temp

def top_N(labels,logits,n=1):
	"""
	parameters:
		labels:N
		logits:N * (m+1)
	"""
	scores_dict=OrderedDict()
	for _batch_index,scores in enumerate(logits):
		sample_dict=dict()
		for _index,score in enumerate(scores):
			sample_dict[_index]=score
		sample_dict=sorted(sample_dict.items(),key = lambda x:x[1],reverse = True)
		results=[tuple_item[0] for tuple_item in sample_dict]
		scores_dict[_batch_index] = results
	all_scores = 0
	for _key,_value in scores_dict.items():
		n_value=_value[:n]
		if 0 in n_value:
			all_scores +=1
	acc_n = all_scores *1.0 / len(labels)
	return acc_n


def TopMetrics(top_list,label_list,logits_list):
	eval_metrics=dict()
	for num in top_list:
		key_metrics = "acc_%d"%(num)
		eval_metrics[key_metrics] = top_N(label_list, logits_list, num)
	return eval_metrics




class TransE(torch.nn.Module):
	def __init__(self, args, embed_matrix,rel2words, ent2word=None):
		super(TransE, self).__init__()
		self.args = args

		self.rel2words = rel2words
		self.ent2word = ent2word
		self.phrase_embed_model = GRUEncoder(embed_matrix, self.args)


		self.np_embeddings = torch.nn.Embedding(self.args.num_nodes, self.args.nfeats)
		torch.nn.init.xavier_normal_(self.np_embeddings.weight.data)
		# self.rp_embeddings = torch.nn.Embedding(self.args.num_rels, self.args.nfeats)
		# torch.nn.init.xavier_normal_(self.rp_embeddings.weight.data)

		self.gamma = torch.Tensor([args.gamma])

		# self.loss = torch.nn.BCELoss()
		self.loss_fct = torch.nn.CrossEntropyLoss()
		self.sim = Similarity(temp=self.args.temp)

		# self.inp_drop = torch.nn.Dropout(self.args.dropout)
		# self.hidden_drop = torch.nn.Dropout(self.args.dropout)
		# self.feature_map_drop = torch.nn.Dropout2d(self.args.dropout)
		#
		# self.conv1 = torch.nn.Conv2d(1, 32, (3, 3))
		# self.bn0 = torch.nn.BatchNorm2d(1)
		# self.bn1 = torch.nn.BatchNorm2d(32)
		# self.bn2 = torch.nn.BatchNorm1d(self.args.nfeats)
		# self.register_parameter('b', torch.nn.Parameter(torch.zeros(self.args.num_nodes)))
		# self.fc = torch.nn.Linear(16128,self.args.nfeats)

		# For the gate network
		# self.W_t = torch.nn.Parameter(torch.zeros(size=(self.args.nfeats, 1)))
		# self.W_s = torch.nn.Parameter(torch.zeros(size=(self.args.nfeats, 1)))
		# self.W_b = torch.nn.Parameter(torch.zeros(size=(1, 1)))
		# torch.nn.init.xavier_uniform_(self.W_t.data, gain=1.414)
		# torch.nn.init.xavier_uniform_(self.W_s.data, gain=1.414)
		# torch.nn.init.xavier_uniform_(self.W_b.data, gain=1.414)

	def forward(self, x, edges):
		return self.cn(x, edges)

	def get_scores(self,ent,rel,tail_embed,batch_size):
		# pdb.set_trace()
		# score = ent + rel - tail_embed
		#
		# cos_sim = self.gamma.item() - torch.norm(score, p=1, dim=1)
		score = ent + rel
		cos_sim = self.sim(score, tail_embed)
		return cos_sim

	def get_embed_my(self, samples, node_id, e_batch, e_len, r_batch, r_len,
					 sub_embed_base, rel_embed_base, tail_embed_base):
		# pdb.set_trace()
		np_embed = self.np_embeddings(node_id)
		np_embed_batch = self.phrase_embed_model(e_batch, e_len)

		rp_embed_batch = self.phrase_embed_model(r_batch, r_len)

		# pdb.set_trace()
		sub_embed = np_embed[samples[:, 0]]
		sub_embed = sub_embed + np_embed_batch
		rel_embed = rp_embed_batch
		tail_embed = np_embed[samples[:, 2]]

		sub_embed = torch.cat([sub_embed, sub_embed_base], dim=1)
		rel_embed = torch.cat([rel_embed, rel_embed_base], dim=1)
		tail_embed = torch.cat([tail_embed, tail_embed_base], dim=1)

		scores = self.get_scores(sub_embed, rel_embed, tail_embed, len(samples))

		return scores

	def get_loss_my(self, samples, labels, node_id, e_batch, e_len, r_batch, r_len):

		cos_sim= self.get_embed_my(samples, node_id, e_batch, e_len, r_batch, r_len)
		# pred = F.sigmoid(scores)
		# predict_loss = self.loss(pred, labels)
		# pdb.set_trace()
		cos_sim = cos_sim.view(self.args.neg_samples + self.args.rel_neg_samples + 1, -1).t()
		labels = torch.zeros(cos_sim.size(0)).long().cuda()
		predict_loss = self.loss_fct(cos_sim, labels)

		# pdb.set_trace()
		# acc =  torch.sum(torch.argmax(cos_sim, dim=1))
		top_list = [1, 2, 5]
		eval_metrics = TopMetrics(top_list, labels, cos_sim)

		return predict_loss, eval_metrics